export class Frase {
    constructor(public fraseEng: string, public frasePtBr: string) { }
}